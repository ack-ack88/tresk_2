To install:

1.) Extract the downloaded zip file into a directory of your choosing.

2.) Start the game. In the main menu click on the Version number located in the top right of the screen,
    this will open the Game Updater window.

3.) In the Game Updater window click "Install". Navigate to the directory where you extracted the mod files
    and select the .gt3ext file. After that you should see the newly installed mod at the top of the Addon
    list.

4.) Click "Play" to return to the main menu.
 